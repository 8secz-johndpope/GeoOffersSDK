//  Copyright © 2019 Zappit. All rights reserved.

#import <UIKit/UIKit.h>

//! Project version number for GeoOffersSDK.
FOUNDATION_EXPORT double GeoOffersSDKVersionNumber;

//! Project version string for GeoOffersSDK.
FOUNDATION_EXPORT const unsigned char GeoOffersSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GeoOffersSDK/PublicHeader.h>


